<?php

use Illuminate\Support\Facades\Route;

use function PHPSTORM_META\type;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome',['name' =>'Samantha']);
});

Route::get('foo', function () {
    return 'Hello World';
});

Route::view('/selamatdatang','welcome');

Route::get('/helloworld', function () {
    return 'Hello world , Pak Dosen!!';
});

Route::get('users/{id}', function ($id) {
    return 'User'.$id;
});

Route::get('perkalian/{bilangan1}/{bilangan2}', function ($bil1,$bil2) {
    return "Hasilnya adalah: ".($bil1 * $bil2);
});

Route::get('perkalian/{bilangan1}/{bilangan2}', function ($bil1=0,$bil2=0) {
    return view('perkalian',["bil1" => ($bil1), "bil2" =>($bil2)]);
});

Route::get('user/{name?}', function ($name) {
    return $name;
});

// named routing
Route::get('user/profile', function () {
    
}) -> name('profile');

Route::get('/catalog/{item?}', function ($type='') {
    return view('catalog',['type' => $type]);
});

Route::get('/type?/{idtype?}', function ($type='', $idtype=0) {
    return view('isicatalog',['type' => $type, 'idtype' => $idtype]);
});





